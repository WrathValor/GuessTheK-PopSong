--| AnalyticsEvents
-- Every analytics event the game sends, in one place (Roblox AnalyticsService). Roblox's
-- limits shape this list:
--   • 100 custom event names per experience        → keep NAMES short and reuse them
--   • 3 custom fields per event (breakdowns)        → Fields = the three, in order
--   • ~8,000 field values in all, then "Other"      → no free text, no user ids in fields
--   • economy: 10 currencies, 20 transaction types, 100 item SKUs
--   • 10 funnels, 100 steps each
--   • 120 + 20 × players requests a minute per server (Engine/Analytics rate-limits)
-- Server code logs through Engine/Analytics; the client may only send the events marked
-- Client = true (through AnalyticsRemote), and only with values from Allowed when given.

local AnalyticsEvents = {}

AnalyticsEvents.Custom = {
	-- [[ Gifting ]] (Engine/GiftService)
	GiftSent = { Fields = { "Paid", "What" } }, -- value: coins spent (Coins) or 1 (Robux)
	-- [[ Rounds + games ]]
	RoundResult = { Fields = { "Song", "Result", "Tier" } }, -- value: seconds to answer (0 = no answer)
	GameFinished = { Fields = { "Outcome", "Mode", "Packs" } }, -- value: correct answers (0-7)
	PerfectGame = { Fields = { "Mode" } },
	SoloStarted = { Fields = { "Theme", "OwnedMix" } },
	StreakReached = { Fields = { "Streak" } }, -- value: new win streak
	StreakLost = { Fields = { "Streak" } }, -- value: the streak that was lost
	LevelUp = { Fields = { "Title" } }, -- value: new level
	OwnedRound = { Fields = { "Whose" } }, -- a round played a song someone in the game owns
	DailySong = { Fields = { "Result", "Try" } }, -- a finished Daily Song. value: tries used; Result Solved / Missed

	-- [[ Queue ]]
	QueueJoined = { Fields = { "Stage", "How" } },
	MatchFound = { Fields = { "Stage" } }, -- value: seconds waited
	QueueLeft = { Fields = { "Stage", "When" } }, -- value: seconds waited
	SoloFromQueue = { Fields = { "How", "Stage" } }, -- value: seconds waited; How Quick (the nudge) / Picker
	-- ghost rival (DuelService.startGhost / Duels): value = seconds waited / the ghost's level;
	-- How Queue (nobody came) / Rematch (Play Again); Source Recorded / Synthetic
	GhostMatched = { Fields = { "How", "Source" } },
	GhostStarted = { Fields = { "Source" } },
	GhostLimit = { Fields = {} }, -- a ghost win past GHOST_DAILY_WINS today. value: that win's number today
	-- waiting alone, moved to a real rival on another stage instead of getting a ghost
	-- (DuelService.scheduleGhost). value: seconds waited; To Waiting (someone alone) / Practice (open practice or a ghost game's results)
	RivalMoved = { Fields = { "To" } },
	-- stepped onto someone's open practice (Settings.SoloOpen, DuelService). When MidGame (their
	-- solo game was on: it ends after the round) / AfterGame (they were on its results)
	JoinedOpenPractice = { Fields = { "Stage", "When" } },
	RematchRequested = { Fields = { "Mode" } },
	RematchStarted = { Fields = { "Mode" } },
	InviteSent = { Fields = { "Stage" } },
	InviteResult = { Fields = { "Result", "Stage" } }, -- Accepted / Declined / Expired / Cancelled / Failed

	-- [[ Party Stages (Engine/PartyService) ]]
	PartyJoined = { Fields = { "Stage", "How" } }, -- How: Host / Walked / Invite / Request
	PartyStarted = { Fields = { "Kind", "Pool" } }, -- value: players; Kind FFA / Duel; Pool All / Custom
	PartyFinished = { Fields = { "Kind", "Place" } }, -- value: correct answers; Place 1st … / Left

	-- [[ Shop / inventory / rewards ]]
	SongRolled = { Fields = { "Result", "Level", "Count" } }, -- Result New / Duplicate; Count "x1" / "x10"
	Equip = { Fields = { "Kind", "Item" } },
	DailyClaimed = { Fields = { "Day" } }, -- value: coins
	QuestClaimed = { Fields = { "Quest" } }, -- value: coins
	SeasonClaim = { Fields = { "Kind" } }, -- value: milestone number
	CardUpgrade = { Fields = { "Song" } }, -- value: copies after
	TicketRoll = { Fields = { "Group", "Result" } }, -- Result New / Duplicate
	QuestBonusClaimed = {},
	GroupRewardClaimed = {},
	-- Invite friends (Engine/ReferralService). How = LaunchData / Referred (Roblox's share link)
	ReferralJoined = { Fields = { "How" } }, -- a new player came from an invite (logged for them)
	ReferralPaid = {}, -- value: friends paid for at once (logged for the inviter)
	ReferralClaimed = { Fields = { "Milestone" } }, -- value: friends played
	CodeRedeemed = { Fields = { "Code" } }, -- value: coins
	SettingChanged = { Fields = { "Setting", "Value" } },
	BadgeEarned = { Fields = { "Badge" } }, -- Constants/BadgeCatalog Key
	QuestSwapped = { Fields = { "From", "To" } }, -- the daily quest swap
	LevelRewardClaimed = { Fields = { "Level" } }, -- value: coins
	-- a coin purchase in the shop (Engine/ShopService). value: the buyer's level. Kind Set /
	-- Stage / Mic / Banner / Photocard / StyleSet; Rarity Common … Legendary, or Regular /
	-- Animated for banners + photocards
	ItemBought = { Fields = { "Kind", "Rarity", "Item" } },
	-- the first stage / mic / set of a rarity a player has ever bought (value: their level), so
	-- "how long until a first Legendary" is a chart
	FirstOfRarity = { Fields = { "Rarity", "Kind" } },
	-- a Robux purchase prompt closed (Engine/ShopService). Product = the catalog id
	-- (Coins1000, Debut, Tickets5…); Kind Coins / Tickets / Upgrades / Bundle / Pass / Streak
	RobuxPrompt = { Fields = { "Product", "Kind", "Result" } }, -- Result Bought / Cancelled

	-- [[ Economy guards (DuelService/Rewards) ]]
	SuspectGame = { Fields = { "Pattern" } }, -- Scoring.Suspect flagged a duel (Instant / Slow); value: rounds that fit
	RivalLimit = { Fields = { "Outcome" } }, -- coins halved by the same-rival guard; value: duels vs them today

	-- [[ From the client ]]
	ScreenOpened = { Fields = { "Screen" }, Client = true, Allowed = {
		Screen = { "Shop", "Roll", "UGC", "Inventory", "Index", "Rewards", "News", "Settings", "Queue", "Results", "SaveStreak", "Tutorial", "Party", "Profile", "PlayerCard", "Invite" },
	} },
	ShopTabOpened = { Fields = { "Tab" }, Client = true, Allowed = {
		Tab = { "Featured", "Perks", "Bundles", "Looks", "Coins", "Codes" }, -- the sidebar quick-jump tabs
	} },
	SoloPickerOpened = { Client = true },
	-- the Save Streak popup answered (value: the streak on offer); shown = ScreenOpened SaveStreak
	SaveStreakOffer = { Fields = { "Result" }, Client = true, Allowed = {
		Result = { "Bought", "Cancelled", "NoThanks", "VIPFree" },
	} },
	-- the Invite Friends button opened Roblox's invite pop-up (or couldn't)
	InvitePrompt = { Fields = { "Result" }, Client = true, Allowed = {
		Result = { "Opened", "Unavailable" },
	} },
	-- a Robux offer tapped outside the shop (Money boards); value 1. Where = the moment
	MoneyOffer = { Fields = { "Offer", "Where" }, Client = true, Allowed = {
		Offer = { "DoubleCoins", "Starter", "Coins", "Tickets", "VIP" },
		Where = { "Results", "Popup", "HUD", "Short" },
	} },
	-- the second favourite ask answered (FavouriteAskController); value 1
	FavouriteAsk = { Fields = { "Result" }, Client = true, Allowed = {
		Result = { "Favourite", "NotNow" },
	} },
	-- the daily login pop-up opened on join (DailyLoginController); value 1
	DailyLoginPopup = { Fields = { "From" }, Client = true, Allowed = {
		From = { "Join" },
	} },
	GroupJoinPrompt = { Fields = { "Result" }, Client = true, Allowed = {
		Result = { "Joined", "AlreadyMember", "Pending", "Cancelled", "Error" },
	} },
	ClipFailed = { Fields = { "Song", "Reason" }, Client = true, Allowed = {
		Reason = { "NotLoaded", "PastEnd", "FetchFailed" },
	} }, -- Song is checked against the library on the server
	ClipLoadTime = { Fields = { "Song" }, Client = true }, -- value: seconds until the clip was ready
	UGCPrompt = { Fields = { "Item", "Where" }, Client = true, Allowed = {
		Where = { "Shop", "Reveal", "Results" },
	} }, -- value: Robux price; Item is checked against the group's catalog on the server

	-- [[ Group UGC (Robux, Engine/UGCService) ]]
	UGCBought = { Fields = { "Item", "Kind" } }, -- value: Robux price
}

-- Coins + XP are the "currencies" in the Economy dashboard (TransactionType + Sku below), with
-- Tickets + Upgrades from rewards and Robux bundles. Roblox keeps only 100 SKUs per experience,
-- so SKUs are kinds, not items: shop sinks use the rarity ("Legendary", "Animated"), Robux
-- sources the product kind ("CoinBundle"), the season track "Track". Per-item detail is in the
-- ItemBought / RobuxPrompt events instead.
AnalyticsEvents.Currencies = { Coins = "Coins", XP = "XP", Tickets = "Tickets", Upgrades = "Upgrades" }
AnalyticsEvents.Transactions = {
	-- sources
	DuelWin = "DuelWin",
	DuelLoss = "DuelLoss",
	DuelDraw = "DuelDraw",
	Perfect = "PerfectBonus",
	Solo = "Solo",
	Party = "PartyMatch",
	Daily = "DailyReward",
	Quest = "Quest",
	QuestBonus = "QuestBonus",
	Group = "GroupReward",
	Referral = "Referral", -- the welcome gift + the inviter's per-friend coins
	LikeGoal = "LikeGoal", -- a like goal hit: everyone's reward
	VIPDaily = "VIPDaily", -- the VIP Pass's free roll ticket each day
	Robux = "RobuxBundle",
	-- sinks
	ShopSet = "ShopSet",
	Gift = "Gift", -- a coin item gifted to someone (sku: Set / Stage / Mic / StyleSet / Banner / Photocard)
	ShopStage = "ShopStage",
	ShopMic = "ShopMic",
	SeasonTrack = "SeasonTrack", -- (a source: milestone coins)
	ShopStyleSet = "ShopStyleSet", -- banner + photocard together
	ShopStyleBanner = "ShopStyleBanner",
	ShopStylePhotocard = "ShopStylePhotocard",
	ShopSong = "ShopSong",
	ShopPack = "ShopPack",
	Roll = "SongRoll", -- also the Tickets sink (sku TicketRoll) and the Upgrades sink (sku CardUpgrade):
	-- Roblox allows 20 transaction types per experience and this list is past that already
	RollRefund = "RollRefund", -- source: coins back for duplicates
}

-- Funnels (10 max). Onboarding uses Roblox's own onboarding funnel: once per player, and
-- logging a step marks every step before it as done, so it only holds the first-game path,
-- in the order everyone walks it. Things that can happen at any time (opening the shop,
-- buying, the daily claim, rolling) stay out of it: they'd tick the earlier steps for players
-- who never played. They have their own events (ScreenOpened, Economy, DailyClaimed, SongRolled).
AnalyticsEvents.Onboarding = {
	"Joined",
	"SteppedOnStage",
	"AnsweredRound",
	"FinishedGame", -- any game: the tutorial, solo practice or a duel
	"FinishedRealDuel", -- a game against real players (a 1v1 or a party), not solo / tutorial
	"WonRealDuel",
}
AnalyticsEvents.Funnels = {
	Duel = { "Queued", "Matched", "Round1", "Round4", "Round7", "Results", "Rematch" },
	Solo = { "PickerOpened", "Started", "Round1", "Round7", "Results", "PlayedAgain" },
	-- one per shop visit: opened the shop → a Robux prompt came up → bought (Engine/ShopService)
	Robux = { "ShopOpened", "Prompted", "Bought" },
	-- the first-join tutorial, one session per player (their UserId). Skipping it is the
	-- "Tutorial" "Skipped" setting event (SettingsService).
	Tutorial = { "Started", "Finished" },
}

return AnalyticsEvents
